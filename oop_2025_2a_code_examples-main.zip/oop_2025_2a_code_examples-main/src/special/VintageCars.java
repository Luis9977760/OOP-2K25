package special;

import advanced.Car;

//public class VintageCars extends Car {
//    void displayStatus(){
//        displayInfo();
//    }
//}
