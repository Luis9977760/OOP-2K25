package advanced;

//class SportsCar extends Car{
//    void displayStatus(){
//        displayInfo();
//    }
//}
